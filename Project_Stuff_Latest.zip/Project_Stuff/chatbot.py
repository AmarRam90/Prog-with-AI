from flask import Flask, render_template, request
import spacy
import spacy.cli  # Add this import
import pandas as pd

app = Flask(__name__)

# Load spaCy model
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    print("Downloading spaCy model 'en_core_web_sm'")
    spacy.cli.download("en_core_web_sm")
    nlp = spacy.load("en_core_web_sm")

# Read products DataFrame
products_df = pd.read_csv("products.csv")

# Store chat history
chat_history = []

# Function to handle different intents
def handle_intent(query, products_df):
    # Process the query using spaCy
    doc = nlp(query)

    # Print tokens for debugging
    print("Tokens:", [token.text for token in doc])

    intent = None

    for token in doc:
        if 'hey' in token.text.lower() or 'hello' in token.text.lower() or 'Assalamualaikum' in token.text.lower():
            intent = "greeting_query"
        elif "price" in token.text.lower():
            intent = "price_query"
            break
        elif "recommend" in token.text.lower():
            intent = "recommendation_query"
            break

    print("Intent:", intent)

    # Handle different intents
    if intent == "greeting_query":
        print("Bota: Assalamualaikum")
    elif intent == "price_query":
        response = handle_price_query(query, products_df)
    elif intent == "recommendation_query":
        response = handle_recommendation_query(query, products_df)
    else:
        response = "Bota:Sorry, I couldn't understand the query."

    return response

def handle_price_query(query, products_df):
    try:
        # Extract numerical values from the query
        price = [float(word.replace("$", "").replace("Rs", "").replace(",", "").strip()) for word in query.split() if word.replace("$", "").replace("Rs", "").replace(",", "").strip().isdigit()]

        if not price:
            return "Bota:No price value found in the query."

        # Filter products under the specified price
        result = products_df[products_df["Price"].astype(float) < price[0]]

        # Display result with formatted output
        return "\nBota:Search Results for Price Query:\n" + "-" * 40 + "\n" + result[["ID", "Name", "Price", "Brand"]].to_string(index=False) + "\n" + "-" * 40

    except ValueError:
        return "Bota:Invalid price format in the query."

def handle_recommendation_query(query, products_df):
    # Extract brand from the query
    brand = [word.capitalize() for word in query.split() if word.isalpha()]

    if not brand:
        return "Bota:No brand mentioned in the query for recommendation."

    brand = brand[-1]  # Take the last word as the brand

    # Recommend products from the same brand
    recommended_products = products_df[products_df["Brand"] == brand].head(3)

    # Prepare HTML for recommended products in a table
    if not recommended_products.empty:
        response = "<table border='1'><tr><th>ID</th><th>Name</th><th>Price</th><th>Brand</th></tr>"
        for index, row in recommended_products.iterrows():
            response += f"<tr><td>{row['ID']}</td><td>{row['Name']}</td><td>{row['Price']}</td><td>{row['Brand']}</td></tr>"
        response += "</table>"
    else:
        response = f"Bota:No products found for {brand}."

    return response


@app.route('/')
def index():
    return render_template('dashboard.html', chat_history=chat_history)

@app.route('/chatbot', methods=['POST'])
def chatbot():
    user_input = request.form['user_input']

    if user_input.lower() == 'bye' or user_input.lower() == 'goodbye' or user_input.lower() == 'ok, take care' or user_input.lower() == 'ok,bye' or user_input.lower() == 'exit':
        response = "Bota: Goodbye!"
    else:
        response = handle_intent(user_input, products_df)

    # Add user and chatbot messages to chat history
    chat_history.append("User: " + user_input)
    chat_history.append(response)

    return response

if __name__ == '__main__':
    app.run(debug=True)
